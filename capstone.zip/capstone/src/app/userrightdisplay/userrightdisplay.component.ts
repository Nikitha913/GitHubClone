import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userrightdisplay',
  templateUrl: './userrightdisplay.component.html',
  styleUrls: ['./userrightdisplay.component.css']
})
export class UserrightdisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
