import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userleftdisplay',
  templateUrl: './userleftdisplay.component.html',
  styleUrls: ['./userleftdisplay.component.css']
})
export class UserleftdisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
