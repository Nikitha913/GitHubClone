import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserleftdisplayComponent } from './userleftdisplay.component';

describe('UserleftdisplayComponent', () => {
  let component: UserleftdisplayComponent;
  let fixture: ComponentFixture<UserleftdisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserleftdisplayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserleftdisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
