import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  readonly APIURL="https://localhost:44328/api/Crud"; 
  constructor(private http:HttpClient) { }
  getUserName():Observable<any[]>{
    return this.http.get<any[]>(this.APIURL);
  }
  getDetails(id:string){
    return this.http.get<any>("https://localhost:44328/api/Crud/"+id);
  }
  postDetails(data:any){
     return this.http.post<any>("https://localhost:44328/api/Crud/",data);
   }
  
}
