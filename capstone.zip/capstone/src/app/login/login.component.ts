import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import {FormGroup,FormBuilder,Validators,FormControl} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms'
import { HttpClient } from '@angular/common/http';
import { Idata } from '../list'; 
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  loginForm!:FormGroup;
  public udata:any=[];
  constructor(private log:LoginService,private http:HttpClient ,private formbuilder:FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.loginForm=this.formbuilder.group({
      name:['',Validators.required],
      password:['',Validators.required],
    })
    this.log.getUserName()
        .subscribe(data=>(this.udata=data));
}
validate(p:object){
  console.log("clicked user");
  console.log(p);
  let user=this.udata.find((x:any)=>(x.name===this.loginForm.value.name)&&(x.password===this.loginForm.value.password))
  console.log("selected object");
  console.log(user);
  if(user==undefined){
    alert("please enter correct details");
  }
  else{
    this.router.navigate(['/useracc',user.Id]);
  }


  
}
}
