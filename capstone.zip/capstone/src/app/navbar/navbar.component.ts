import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  details:any;
  search:string="";
  constructor(private log:LoginService) { }

  ngOnInit(): void {
    this.log.getUserName()
    .subscribe(data=>{
      this.details=data
      console.log("data",data)
      console.log(this.details);
      for(let i=0;i<this.details.length;i++){
      console.log("details",this.details[i].name);
      }

    });
    
  }
  display(){
    console.log(this.search);
  }

}
