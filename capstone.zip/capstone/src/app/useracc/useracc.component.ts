import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { LoginService } from '../login.service';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
  selector: 'app-useracc',
  templateUrl: './useracc.component.html',
  styleUrls: ['./useracc.component.css']
})

export class UseraccComponent implements OnInit {
  details:any;
  search:any;
  repo:any;
  res:string="no repositories";
  bool:boolean=false;
   user:any=this.route.snapshot.paramMap.get('user');
  constructor(private router:Router,public route:ActivatedRoute,private login:LoginService,private form:FormsModule) { }
 
  ngOnInit(): void {
    console.log(this.user);
    this.login.getDetails(this.user)
        .subscribe(data=>{
          this.details=data
          console.log("reposiroty");
          console.log(this.details.repository);
          // this.repo=JSON.stringify(this.details.repository);
          // console.log(this.repo);
        });  
  }
  searchrepo(){
    this.bool=false;
    console.log(this.search);
    console.log(this.bool);
    //console.log(this.details.repository.length)
    for(let i=0;i<this.details.repository.length;i++){
      console.log("finding");
      console.log(this.details.repository[0].RepoName);
      if(this.search==this.details.repository[i].RepoName){
          this.bool=true;
          console.log("yes");
          console.log(this.bool);
          this.res=this.search;
      }
    }
  }
  display(reponame:[]){
    console.log("found");
    console.log(this.details.repository['reponame']);
    // document.write("found");
    
  }
 

}
