export interface Idata{
    Name:string,
    password:string
}