import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NewaccComponent } from './newacc/newacc.component';
import { LoginService } from './login.service';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UseraccComponent } from './useracc/useracc.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { UserleftdisplayComponent } from './userleftdisplay/userleftdisplay.component';
import { UserrightdisplayComponent } from './userrightdisplay/userrightdisplay.component';
import { CardComponent } from './card/card.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SearchComponent } from './search/search.component';
import { ProfileComponent } from './profile/profile.component';
import { OverviewComponent } from './overview/overview.component';
import { RepositoriesComponent } from './repositories/repositories.component';
import { FilesComponent } from './files/files.component';
import { FindComponent } from './find/find.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NewaccComponent,
    UseraccComponent,
    NavbarComponent,
    FooterComponent,
    UserleftdisplayComponent,
    UserrightdisplayComponent,
    CardComponent,
    SearchComponent,
    ProfileComponent,
    OverviewComponent,
    RepositoriesComponent,
    FilesComponent,
    FindComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule,
    RouterModule,ReactiveFormsModule,
    FormsModule ,HttpClientModule,
    
    
  ],
  providers: [LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
