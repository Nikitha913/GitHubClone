import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-files',
  templateUrl: './files.component.html',
  styleUrls: ['./files.component.css']
})
export class FilesComponent implements OnInit {
  details:any;
 reponame:any=this.router.snapshot.paramMap.get('repo')
 user:any=this.router.snapshot.paramMap.get('user');
  constructor(private router:ActivatedRoute,private log:LoginService) { }

  ngOnInit(): void {
    this.log.getDetails(this.user)
    .subscribe(data=>{
     
      this.details=data
      console.log(this.details.repository);
    })
  }

}
