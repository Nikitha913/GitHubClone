import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
search:string="";
details:any;
res:string="no repositories";
bool:boolean=false;
user:any=this.router.snapshot.paramMap.get('user');
  constructor(private log:LoginService,private router:ActivatedRoute) { }
  
  ngOnInit(): void {
    this.log.getDetails(this.user)
        .subscribe(data=>{
          //console.log(data);
          this.details=data
          //console.log(this.details.repository);
        })
   
  }
searchrepo(){
  console.log(this.search);
  this.bool=false;
  console.log(this.search);
  console.log(this.bool);
  //console.log(this.details.repository.length)
  for(let i=0;i<this.details.repository.length;i++){
    console.log("finding");
    console.log(this.details.repository[0].RepoName);
    if(this.search==this.details.repository[i].RepoName){
        this.bool=true;
        console.log("yes");
        console.log(this.bool);
        this.res=this.search;
    }
  }
}
}
