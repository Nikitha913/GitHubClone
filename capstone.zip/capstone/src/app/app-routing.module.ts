import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FilesComponent } from './files/files.component';
import { FindComponent } from './find/find.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NewaccComponent } from './newacc/newacc.component';
import { OverviewComponent } from './overview/overview.component';
import { ProfileComponent } from './profile/profile.component';
import { RepositoriesComponent } from './repositories/repositories.component';
import { UseraccComponent } from './useracc/useracc.component';



const routes: Routes = [
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'',
    component:HomeComponent
  },
  {
    path:'newacc',
    component:NewaccComponent
  },
  {
    path:'useracc/:user',
    component:UseraccComponent
  },
  {
    path:'newacc',
    component:NewaccComponent, 
  },
  {
    path:'profile/:user',
    component:ProfileComponent,
    children:[
   {
    path: 'overview/:user',
    component:OverviewComponent,
    outlet:'auxii',
    children:[ 
      {
      path:'files/:repo/:user',
      component:FilesComponent,
      outlet:'repos'
     }
    ]
   },
   {
     path: 'find/:bool/:res',
     component: FindComponent,
     outlet:'auxii'
   },
   {
    path: 'repo',
    component : RepositoriesComponent,
    outlet: 'auxii'
   } 
  ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
