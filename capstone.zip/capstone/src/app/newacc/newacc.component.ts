import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-newacc',
  templateUrl: './newacc.component.html',
  styleUrls: ['./newacc.component.css']
})
export class NewaccComponent implements OnInit {
  accForm!:FormGroup;
  accdetails:any;
  constructor(private builder:FormBuilder,private log:LoginService) { }

  ngOnInit(): void {
    this.accForm=this.builder.group({
      name:['',Validators.required],
      password:['',Validators.required],
    })
   
  }
  post(){
    //console.log(p);
  let t=  {
      "name": this.accForm.value.name,
      "password": this.accForm.value.password,
      "repository": [
        {
          "repoName": "data",
          "files": [
            "file1","file2","file3"
          ]
          
        }
      ]
    }
 
  this.log.postDetails(t)

      .subscribe({
        next:(response)=>{

          alert('Account created Succefully')
          } ,
        error:()=>{
          alert('Sorry!Account not created')
        }
      })

    }
}
