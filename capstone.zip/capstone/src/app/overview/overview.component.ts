import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})

export class OverviewComponent implements OnInit {
  details:any;
  user:any=this.router.snapshot.paramMap.get('user');
  constructor(private log:LoginService,private router:ActivatedRoute) { }

  ngOnInit(): void {
    console.log(this.user);
    this.log.getDetails(this.user)
    .subscribe(data=>{
      //console.log(data);
      this.details=data
      console.log(this.details.repository);
    })
  }

}
