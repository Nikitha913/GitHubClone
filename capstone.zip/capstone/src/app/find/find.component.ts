import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-find',
  templateUrl: './find.component.html',
  styleUrls: ['./find.component.css']
})

export class FindComponent implements OnInit {
  bool:any=this.router.snapshot.paramMap.get('bool');
  res:any=this.router.snapshot.paramMap.get('res');
  constructor(private router:ActivatedRoute) { }

  ngOnInit(): void {
  }

}
