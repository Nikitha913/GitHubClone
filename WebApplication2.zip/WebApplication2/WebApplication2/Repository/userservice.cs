﻿using System.Collections.Generic;
using WebApplication2.Models;
using MongoDB.Bson;
using MongoDB.Driver;
namespace WebApplication2.Repository
{
    public class userservice:IRepository.IService
    {
        private MongoClient _client;
        private IMongoDatabase _database;
        private IMongoCollection<User> _users;  

        public userservice()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.pfoqw3s.mongodb.net/test");
            _database = _client.GetDatabase("Project");
            _users = _database.GetCollection<User>("Login");
        }
        public List<User> GetAll()
        {
            //return _users.Find(user => true).ToList();
            return _users.Find<User>(user => true).ToList();
        }
        public User AddUser(User user)
        {
            _users.InsertOne(user);
            return user;
        }
        public User GetUser(string id)
        {
            var values = _users.Find(user => user.Id == id).First();
            //var test = BsonSerializer.Deserialize<IEnumerable<User>>((MongoDB.Bson.IO.IBsonReader)values);
            //return (User)test;
            return values;
        }
        public User PutUser(string id, User user)
        {
            _users.ReplaceOne(user => user.Id == id, user);
            return user;
        }

    }
}
