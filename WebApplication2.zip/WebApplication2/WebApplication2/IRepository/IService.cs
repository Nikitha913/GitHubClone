﻿using WebApplication2.Repository;
using System.Collections.Generic;
using WebApplication2.Models;
namespace WebApplication2.IRepository
{
    public interface IService
    {
        List<User> GetAll();
        User AddUser(User user);
        User GetUser(string id);
        User PutUser(string id, User user);
    }
}
