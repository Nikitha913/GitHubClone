﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Logging;
//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Net.Http;
//using System.Text.Json;
//using System.Threading.Tasks;

//namespace WebApplication2.Controllers
//{

//    [ApiController]
//    [Route("[controller]")]
//    public class WeatherForecastController : ControllerBase
//    {
//        [HttpGet]
//        public async Task<List<Student>> GetAll() 
//        {
//            //string url = "https://63539e82ccce2f8c02f9ceee.mockapi.io/api";
//            //HttpClient httpClient = new HttpClient();
//            //using (var response = await httpClient.GetAsync(url))
//            //{
//            //    response.EnsureSuccessStatusCode();
//            //    var responseBody=await response.Content.ReadAsStreamAsync();
//            //    var result = await JsonSerializer.DeserializeAsync<List<Student>>(responseBody);
//            //    return result;
//            //}
//            SqlConnection connection = new SqlConnection("Server=APINP-ELPT75480\\SQLEXPRESS;Database=Learning;Integrated Security=true;user id=sa;password=guvi");
//            connection.Open();
//            string query = "select * from student";
//            SqlCommand cmd=new SqlCommand(query, connection);
//            var a = cmd.ExecuteReader();
//            if (a.HasRows)
//            {
//                List<Student> students = new List<Student>();
//                Student student = null;
//                while (a.Read())
//                {
//                    student = new Student();
//                    student.id = Convert.ToInt32(a["id"]);
//                    student.Name = a["name"].ToString();
//                    student.Dept = a["dept"].ToString();

//                    students.Add(student);
//                }
//                return students;
//            }
//        }






//    }
//}



using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption.ConfigurationModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
 

namespace API.Controllers
{
    public class Student
    {
        public string name { get; set; }
        public string password { get; set; }
        public string createdAt { get; set; }
    }


    [ApiController]
    [Route("api/v1/student")]
    public class WeatherForecastController : ControllerBase
    {

        [HttpGet]
        public List<Student> GetAll()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT75480\\SQLEXPRESS;Database=project;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                string query = "select * from login";

                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<Student> students = new List<Student>();
                    Student student = null;
                    while (a.Read())
                    {
                        student = new Student();
                        student.name = a["name"].ToString();
                        student.password = a["password"].ToString();
                        students.Add(student);
                    }
                    return students;
                }
            }
            catch (Exception)
            {

                throw;
            }



            return null;


        }//
        [HttpPost]
        public void Post(string name,string password)
        {
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT75480\\SQLEXPRESS;Database=project;Integrated Security=false;User Id=sa;Password=guvi;");
            connection.Open();
            string  query = "insert into login (name,password) values(@name,@password)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.Add("@name", SqlDbType.NVarChar).Value = name;
            command.Parameters.Add("@password", SqlDbType.NVarChar).Value = password;
            command.ExecuteNonQuery();
        }
        [HttpDelete]
        public void Delete(string n)
        {
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT75480\\SQLEXPRESS;Database=project;Integrated Security=false;User Id=sa;Password=guvi;");
            connection.Open();
            string query = "DELETE * FROM login WHERE name=@n";
            SqlCommand command = new SqlCommand(query, connection);
            command.ExecuteNonQuery();
        }
    }
}

