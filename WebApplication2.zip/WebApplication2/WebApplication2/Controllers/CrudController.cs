﻿using WebApplication2.Models;
using MongoDB.Bson;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CrudController : ControllerBase
    {
        private readonly IRepository.IService userService1;
        public CrudController(IRepository.IService userservice)
        {
            userService1 = userservice;
        }
        [HttpGet]
        public IActionResult getAll()
        {
            return Ok(userService1.GetAll());
        }
        [HttpPost]
        public IActionResult AddUser(User user)
        {
            userService1.AddUser(user);
            return Ok(user);    
        }
        [HttpGet("{id}", Name = "GetUser")]
        public IActionResult GetUser(string id)
        {
            return Ok(userService1.GetUser(id));
        }
        [HttpPut("{id}")]
        public IActionResult PutUser(string id, [FromBody] User user)
        {
            userService1.PutUser(id, user);
            return NoContent();
        }
    }
}
