﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public class User
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonId]
        public string Id { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public List<repo> repository { get; set; }

       // public string[] repository { get; set; }    
    }
    public class repo
    {
        public string RepoName { get; set; }
        public string[] Files { get; set; }
    }
}
